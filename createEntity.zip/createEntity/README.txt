・既存のデータベースからテーブルに対応するクラス群を自動生成
ConnectionStringテキストファイルに接続文字列を入れ、createEntiyバッチファイルを実行することで、生成される(Modelsファイルが生成されその中にクラスが入っている)

・最低限必要な接続文字列(SQL Server 認証)
Data Source：データベースファイル名
Initial Catalog：データベース名
User ID：ユーザーID
Password：パスワード
Encrypt：SSL暗号化

(例)
Data Source = TMACHINO-PC;Initial Catalog = 27Training;User ID = admin;Password = 1234;Encrypt=False

